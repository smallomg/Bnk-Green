package r13;

public class CustomerManager {

	public static VIPCustomer createVipCustomer(Customer customer) {
		VIPCustomer vc = new VIPCustomer();

		return vc;
	}
}
