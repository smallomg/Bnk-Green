package 평가;

public class Member {

}
